from .._models import BaseModel

__all__ = ["OutputTokensDetails"]


class OutputTokensDetails(BaseModel):
    thinking_tokens: int
    """
    Number of output tokens the model generated as internal reasoning, including the
    thinking-block delimiter tokens.

    Reflects the raw reasoning the model produced, not the (possibly shorter)
    summarized thinking text returned in the response body. Computed by
    re-tokenizing the raw reasoning text, so it may differ from the model's exact
    generation count by a small number of tokens. Always ≤ `output_tokens`;
    `output_tokens - thinking_tokens` approximates the non-reasoning output.
    """
