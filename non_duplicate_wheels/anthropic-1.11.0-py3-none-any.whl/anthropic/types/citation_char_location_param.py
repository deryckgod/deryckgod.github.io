from __future__ import annotations

from typing import Optional
from typing_extensions import Literal, Required, TypedDict

__all__ = ["CitationCharLocationParam"]


class CitationCharLocationParam(TypedDict, total=False):
    cited_text: Required[str]

    document_index: Required[int]

    document_title: Required[Optional[str]]

    end_char_index: Required[int]

    start_char_index: Required[int]

    type: Required[Literal["char_location"]]
