from typing_extensions import Literal, TypeAlias

__all__ = ["StopReason"]

StopReason: TypeAlias = Literal[
    "end_turn", "max_tokens", "stop_sequence", "tool_use", "pause_turn", "refusal", "model_context_window_exceeded"
]
