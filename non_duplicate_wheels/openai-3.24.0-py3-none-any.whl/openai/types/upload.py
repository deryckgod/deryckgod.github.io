# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from .._models import BaseModel
from .file_object import FileObject

__all__ = ["Upload"]


class Upload(BaseModel):
    """The Upload object can accept byte chunks in the form of Parts."""

    id: str
    """The Upload unique identifier, which can be referenced in API endpoints."""

    bytes: int
    """The intended number of bytes to be uploaded."""

    created_at: int
    """The Unix timestamp (in seconds) for when the Upload was created."""

    expires_at: int
    """The Unix timestamp (in seconds) for when the Upload will expire."""

    filename: str
    """The name of the file to be uploaded."""

    object: Literal["upload"]
    """The object type, which is always "upload"."""

    purpose: str
    """The intended purpose of the file.

    [Please refer here](https://developers.openai.com/api/reference/resources/files#%28resource%29%20files%20%3E%20%28model%29%20file_object%20%3E%20%28schema%29%20%3E%20%28property%29%20purpose)
    for acceptable values.
    """

    status: Literal["pending", "completed", "cancelled", "expired"]
    """The status of the Upload."""

    file: Optional[FileObject] = None
    """The `File` object represents a document that has been uploaded to OpenAI."""
