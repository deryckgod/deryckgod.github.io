# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""AWS Bedrock provider package (Claude via SigV4-authenticated Bedrock Runtime)."""

from .provider import (
    BEDROCK_DEFAULT_MODEL,
    BEDROCK_DEFAULT_REGION,
    BEDROCK_SDK_TOTAL_MAX_ATTEMPTS,
    REGISTRY_PATH,
    BedrockProvider,
)

__all__ = [
    "BEDROCK_DEFAULT_MODEL",
    "BEDROCK_DEFAULT_REGION",
    "BEDROCK_SDK_TOTAL_MAX_ATTEMPTS",
    "REGISTRY_PATH",
    "BedrockProvider",
]
