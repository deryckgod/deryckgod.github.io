# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Base LLM Analyzer with per-file / per-chunk batching (truncation-safe).

Provides ``LLMAnalyzerBase`` — a reusable run-loop that splits work into one
LLM call per file (or per chunk when a file exceeds the model's input budget),
using token budgets from ``constants.py`` so no single prompt is truncated.

The default ``response_schema`` is :class:`LLMAnalysisResult` (a list of
:class:`LLMFinding`), suitable for discovery-mode analyzers.  Subclasses may
override :attr:`response_schema` with a different Pydantic model, or set it
to ``None`` for raw-string mode.
"""

from __future__ import annotations

import asyncio
import os
import threading
import time
from collections import defaultdict, deque
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from email.utils import parsedate_to_datetime
from random import uniform
from typing import Any, Literal, cast

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import BaseMessage
from langchain_openai.chat_models.base import BaseChatOpenAI
from pydantic import BaseModel, Field, ValidationError, field_validator

from skillspector.inference_usage import (
    InferenceUsageRecord,
    chat_model_controls,
    chat_model_requested_controls,
)
from skillspector.inspection_ledger import (
    AnalyzerStatusEvent,
    InspectionLedgerEvent,
    LedgerOutcome,
    LedgerReason,
    analyzer_status_for_events,
    ledger_event,
    outcome_for_llm_batch_failure,
)
from skillspector.llm_utils import (
    AgentCLIChatModel,
    StructuredOutputParseError,
    _AgentCLIMessage,
    _ainvoke_with_usage,
    _invoke_with_usage,
    bind_structured_output,
    chat_model_provider_name,
    get_chat_model,
    new_inference_usage_collector,
)
from skillspector.logging_config import get_logger
from skillspector.model_info import get_max_input_tokens
from skillspector.models import Finding
from skillspector.providers import get_active_provider
from skillspector.providers.gemini import GeminiProvider

logger = get_logger(__name__)

DEFAULT_MAX_LLM_CONCURRENCY = 10
API_CONNECTION_MAX_RETRIES = 3
API_CONNECTION_RETRY_DELAYS_SECONDS = (0.5, 1.0, 2.0)
RATE_LIMIT_RETRY_DELAYS_SECONDS = (5.0, 15.0, 30.0)
PROVIDER_RETRY_AFTER_MAX_SECONDS = 60.0
STRUCTURED_RESPONSE_MAX_RETRIES = 3
STRUCTURED_RESPONSE_MAX_ATTEMPTS = STRUCTURED_RESPONSE_MAX_RETRIES + 1
STRUCTURED_RESPONSE_RETRY_DELAYS_SECONDS = API_CONNECTION_RETRY_DELAYS_SECONDS
LLM_BATCH_MAX_ATTEMPTS = STRUCTURED_RESPONSE_MAX_ATTEMPTS + API_CONNECTION_MAX_RETRIES
OUTPUT_LANGUAGE_MAX_LENGTH = 64


def resolve_output_language() -> str | None:
    """Return the configured language for human-readable LLM finding text."""
    raw_language = os.environ.get("SKILLSPECTOR_OUTPUT_LANGUAGE", "")
    language = raw_language.strip()
    if not language:
        return None
    if (
        "\r" in raw_language
        or "\n" in raw_language
        or len(language) > OUTPUT_LANGUAGE_MAX_LENGTH
        or not all(character.isalnum() or character in " -_" for character in language)
    ):
        return None
    return language


def append_output_language_instruction(prompt: str) -> str:
    """Append the optional output-language contract to an analyzer prompt."""
    language = resolve_output_language()
    if language is None:
        return prompt
    return (
        f"{prompt}\n\n## Output language\n\n"
        "Write human-readable finding text (including message, finding, explanation, "
        f"remediation, and intent fields when present) in {language}. Keep rule IDs, "
        "severity values, categories, file paths, code, and other machine-readable values "
        "unchanged."
    )


class _StructuredResponseValidationError(Exception):
    """Signal that provider output failed structured-response validation."""


class LLMRuntimeLimitError(RuntimeError):
    """Signal that no shared scan time remains for an LLM operation."""


_RETRYABLE_PROVIDER_ERROR_NAMES = frozenset(
    {
        "APIConnectionError",
        "APITimeoutError",
        "ConnectionClosedError",
        "ConnectionError",
        "ConnectError",
        "ConnectTimeout",
        "ConnectTimeoutError",
        "EndpointConnectionError",
        "HTTPClientError",
        "InternalServerError",
        "ModelNotReadyException",
        "PoolTimeout",
        "ProxyConnectionError",
        "RateLimitError",
        "ReadTimeout",
        "ReadTimeoutError",
        "RemoteProtocolError",
        "ResponseStreamingError",
        "ServiceUnavailableError",
        "SSLError",
        "ThrottlingException",
        "WriteTimeout",
    }
)
_RETRYABLE_PROVIDER_STATUS_CODES = frozenset({408, 409, 425, 429})
_NATIVE_RETRYABLE_PROVIDER_ERROR_NAMES = frozenset({"APIConnectionError", "APITimeoutError"})
_NATIVE_RETRYABLE_PROVIDER_STATUS_CODES = frozenset({408, 409, 429})
_RETRYABLE_BEDROCK_ERROR_CODES = frozenset(
    {
        "ec2throttledexception",
        "internalserverexception",
        "modelnotreadyexception",
        "priorrequestnotcomplete",
        "requestlimitexceeded",
        "requesttimeout",
        "requesttimeoutexception",
        "servicetemporarilyunavailable",
        "serviceunavailableexception",
        "slowdown",
        "throttling",
        "throttlingexception",
        "toomanyrequestsexception",
    }
)


def _exception_chain(exc: BaseException) -> list[BaseException]:
    """Return a short, cycle-safe exception chain for provider wrappers."""
    chain: list[BaseException] = []
    seen: set[int] = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen and len(chain) < 8:
        chain.append(current)
        seen.add(id(current))
        current = current.__cause__ or current.__context__
    return chain


def _provider_status_code(exc: BaseException) -> int | None:
    """Read an HTTP status from OpenAI, Anthropic, httpx, or botocore shapes."""
    response = getattr(exc, "response", None)
    candidates: list[object] = [getattr(exc, "status_code", None)]
    if isinstance(response, Mapping):
        metadata = response.get("ResponseMetadata")
        if isinstance(metadata, Mapping):
            candidates.append(metadata.get("HTTPStatusCode"))
    elif response is not None:
        candidates.append(getattr(response, "status_code", None))
    for value in candidates:
        if isinstance(value, int) and not isinstance(value, bool):
            return value
    return None


def _bedrock_error_code(exc: BaseException) -> str | None:
    """Read the stable AWS error code from a botocore ClientError-like object."""
    response = getattr(exc, "response", None)
    if not isinstance(response, Mapping):
        return None
    error = response.get("Error")
    if not isinstance(error, Mapping):
        return None
    code = error.get("Code")
    return str(code).strip().lower() if code else None


def _provider_headers(exc: BaseException) -> list[Mapping[object, object]]:
    """Return response-header mappings without assuming one provider SDK."""
    response = getattr(exc, "response", None)
    sources: list[object] = [getattr(exc, "headers", None)]
    if isinstance(response, Mapping):
        metadata = response.get("ResponseMetadata")
        if isinstance(metadata, Mapping):
            sources.append(metadata.get("HTTPHeaders"))
        sources.append(response.get("headers"))
    elif response is not None:
        sources.append(getattr(response, "headers", None))
    return [source for source in sources if isinstance(source, Mapping)]


def _provider_retry_override(exc: BaseException) -> bool | None:
    """Read the common explicit provider retry override, when present."""
    for source in _provider_headers(exc):
        headers = {str(key).lower(): str(value).strip().lower() for key, value in source.items()}
        value = headers.get("x-should-retry")
        if value == "false":
            return False
        if value == "true":
            return True
    return None


def _transient_provider_cause(exc: BaseException) -> BaseException | None:
    """Return the causal exception that identifies a transient provider failure."""
    for candidate in _exception_chain(exc):
        if isinstance(candidate, (ConnectionError, TimeoutError)):
            return candidate
        if type(candidate).__name__ in _RETRYABLE_PROVIDER_ERROR_NAMES:
            return candidate
        status_code = _provider_status_code(candidate)
        if status_code in _RETRYABLE_PROVIDER_STATUS_CODES or (
            status_code is not None and 500 <= status_code <= 599
        ):
            return candidate
        if _bedrock_error_code(candidate) in _RETRYABLE_BEDROCK_ERROR_CODES:
            return candidate
    return None


def _is_retryable_provider_error(exc: BaseException) -> bool:
    """Return whether coordinator policy permits retrying this provider failure."""
    for candidate in _exception_chain(exc):
        override = _provider_retry_override(candidate)
        if override is not None:
            return override
    return _transient_provider_cause(exc) is not None


def _native_retries_cover_provider_error(exc: BaseException) -> bool:
    """Return whether the configured OpenAI/Anthropic SDK retries this failure.

    Their locked SDK versions cover connection failures, 408/409/429, and 5xx,
    but not 425. Keeping this narrower than the coordinator policy prevents a
    retryable status that the SDK does not own from being dropped after one call.
    """
    for candidate in _exception_chain(exc):
        override = _provider_retry_override(candidate)
        if override is not None:
            return override
        if isinstance(candidate, (ConnectionError, TimeoutError)):
            return True
        if type(candidate).__name__ in _NATIVE_RETRYABLE_PROVIDER_ERROR_NAMES:
            return True
        status_code = _provider_status_code(candidate)
        if status_code in _NATIVE_RETRYABLE_PROVIDER_STATUS_CODES or (
            status_code is not None and 500 <= status_code <= 599
        ):
            return True
    return False


@dataclass
class _ProviderRetryOutcome:
    """Per-batch evidence of why the coordinator stopped retrying."""

    reason: LedgerReason = LedgerReason.LLM_BATCH_FAILED


def _provider_failure_class(exc: BaseException) -> str:
    """Preserve the initiating transient exception class through wrappers."""
    cause = _transient_provider_cause(exc)
    return type(cause or exc).__name__


def _is_rate_limit_provider_error(exc: BaseException) -> bool:
    """Return whether a retryable provider failure represents quota throttling."""
    rate_limit_codes = {
        "ec2throttledexception",
        "requestlimitexceeded",
        "slowdown",
        "throttling",
        "throttlingexception",
        "toomanyrequestsexception",
    }
    for candidate in _exception_chain(exc):
        override = _provider_retry_override(candidate)
        if override is False:
            return False
        if type(candidate).__name__ in {"RateLimitError", "ThrottlingException"}:
            return True
        if _provider_status_code(candidate) == 429:
            return True
        if _bedrock_error_code(candidate) in rate_limit_codes:
            return True
    return False


def _provider_retry_after_seconds(exc: BaseException) -> float | None:
    """Return a bounded provider-requested retry delay from common response shapes."""
    for candidate in _exception_chain(exc):
        for source in _provider_headers(candidate):
            headers = {str(key).lower(): value for key, value in source.items()}
            raw_milliseconds = headers.get("retry-after-ms")
            if raw_milliseconds is not None:
                try:
                    delay = float(str(raw_milliseconds)) / 1000.0
                except (TypeError, ValueError):
                    pass
                else:
                    if delay >= 0:
                        return min(delay, PROVIDER_RETRY_AFTER_MAX_SECONDS)

            for header in ("retry-after", "x-amz-retry-after"):
                raw_delay = headers.get(header)
                if raw_delay is None:
                    continue
                try:
                    delay = float(str(raw_delay))
                except (TypeError, ValueError):
                    try:
                        retry_at = parsedate_to_datetime(str(raw_delay))
                    except (TypeError, ValueError, OverflowError):
                        continue
                    if retry_at.tzinfo is None:
                        continue
                    delay = max(0.0, retry_at.timestamp() - time.time())
                if delay >= 0:
                    return min(delay, PROVIDER_RETRY_AFTER_MAX_SECONDS)
    return None


def _provider_retry_delay(exc: BaseException, retries_used: int) -> float:
    """Jitter each retry above the bounded provider-requested minimum delay."""
    schedule = (
        RATE_LIMIT_RETRY_DELAYS_SECONDS
        if _is_rate_limit_provider_error(exc)
        else API_CONNECTION_RETRY_DELAYS_SECONDS
    )
    scheduled = schedule[retries_used]
    minimum = _provider_retry_after_seconds(exc) or 0.0
    # Full jitter spreads concurrent retries, including when the provider sends
    # the same Retry-After hint to every batch. Keep the existing total delay cap;
    # the invocation loops also check this sampled delay against the scan deadline.
    return uniform(minimum, min(minimum + scheduled, PROVIDER_RETRY_AFTER_MAX_SECONDS))


def _uses_native_connection_retries(
    chat_model: object,
    *,
    max_retries: int = API_CONNECTION_MAX_RETRIES,
) -> bool:
    """Set the native retry budget and report whether native retries remain enabled."""
    if isinstance(chat_model, BaseChatOpenAI):
        for client in (chat_model.root_client, chat_model.root_async_client):
            if client is not None:
                client.max_retries = max_retries
        return max_retries > 0
    if isinstance(chat_model, ChatAnthropic):
        chat_model.max_retries = max_retries
        return max_retries > 0
    return False


def _retarget_request_timeout(chat_model: object, timeout: float | None) -> bool:
    """Point an existing chat model at *timeout* and report whether it took effect.

    Returns ``False`` for transports that keep no mutable deadline, so the caller can
    fall back to constructing a replacement model for that call.
    """
    if isinstance(chat_model, BaseChatOpenAI):
        clients = (chat_model.root_client, chat_model.root_async_client)
        if any(client is None for client in clients):
            return False
        for client in clients:
            client.timeout = timeout
        chat_model.request_timeout = timeout
        return True
    if isinstance(chat_model, ChatAnthropic):
        # ``timeout <= 0`` is how ChatAnthropic spells "leave the SDK default alone"; an
        # expired deadline never reaches here because ``_require_time_remaining`` raises first.
        for client in (chat_model._client, chat_model._async_client):
            client.timeout = timeout
        chat_model.default_request_timeout = timeout
        return True
    if isinstance(chat_model, AgentCLIChatModel):
        chat_model.set_timeout(timeout)
        return True
    return False


# ONE BUDGET FOR THE PROCESS, AND IT CANNOT BE AN asyncio.Semaphore.
#
# The analyzers are separate graph nodes and each node is a *synchronous* function: it reaches
# ``run_async()``, which calls ``asyncio.run()`` — and, when a loop is already running, does so on
# a fresh thread. Every analyzer therefore gets its own event loop. An ``asyncio.Semaphore`` is
# bound to the loop that created it, so one semaphore per loop is one semaphore per analyzer, and
# the process still puts N x limit requests on the wire. That is the burst
# ``SKILLSPECTOR_MAX_LLM_CONCURRENCY`` exists to prevent: users set it to 1 on a free tier
# precisely because a burst guarantees 429s, and 429'd batches are dropped from the result.
#
# So the permits live outside asyncio, under a plain lock, and each waiter parks on a future
# belonging to *its own* loop. Releasing hands the permit to the next waiter through that loop's
# ``call_soon_threadsafe``, which is the one asyncio primitive that is safe to call from another
# thread. Nothing blocks a worker thread while it waits, which rules out the obvious alternative
# of wrapping a ``threading.Semaphore`` in ``run_in_executor``: that pins one thread per queued
# request, and the queue is exactly as long as the fan-out this is meant to bound.
class _Handover:
    """One queued waiter, plus the fact of whether the permit was already given to it.

    ``granted`` is the whole point. A permit changes hands in two steps — taken out of the queue
    here, delivered by ``_settle`` on the waiter's own loop — and the waiter can be cancelled
    between them. Asking the future what happened cannot answer that question: a cancelled future
    looks exactly like one that was never chosen. So the transfer is recorded explicitly, under
    the same lock that performs it.
    """

    __slots__ = ("future", "granted", "loop")

    def __init__(self, loop: asyncio.AbstractEventLoop, future: asyncio.Future) -> None:
        self.loop = loop
        self.future = future
        self.granted = False


class _GlobalLLMLimiter:
    """A permit counter shared by every event loop and thread in the process."""

    def __init__(self, limit: int) -> None:
        self._limit = max(1, limit)
        self._lock = threading.Lock()
        self._in_flight = 0
        # Arrival order. FIFO, so a late analyzer is not starved by an early one that keeps
        # re-acquiring.
        self._waiters: deque[_Handover] = deque()

    async def acquire(self) -> None:
        loop = asyncio.get_running_loop()
        with self._lock:
            if self._in_flight < self._limit:
                self._in_flight += 1
                return
            handover = _Handover(loop, loop.create_future())
            self._waiters.append(handover)
        try:
            await handover.future
        except BaseException:
            # Cancelled or timed out while queued. Leaving the waiter in the deque would let a
            # later release() hand a permit to a coroutine that is already gone, and the permit
            # would never come back.
            with self._lock:
                try:
                    self._waiters.remove(handover)
                except ValueError:
                    pass  # already taken out of the queue: the handover was in flight
                granted = handover.granted
            if granted:
                # The permit was handed to us and nobody will use it — whether the callback has
                # run yet or is still queued on this loop. Pass it on rather than leak it.
                self.release()
            raise

    def release(self) -> None:
        with self._lock:
            while self._waiters:
                handover = self._waiters.popleft()
                if handover.future.cancelled():
                    continue
                try:
                    # The permit is transferred, not returned: _in_flight stays as it is.
                    handover.granted = True
                    handover.loop.call_soon_threadsafe(_settle, handover.future)
                except RuntimeError:
                    # That loop is closed — its waiter can never run. Try the next one.
                    handover.granted = False
                    continue
                return
            self._in_flight = max(0, self._in_flight - 1)

    async def __aenter__(self) -> _GlobalLLMLimiter:
        await self.acquire()
        return self

    async def __aexit__(self, *_exc: object) -> None:
        self.release()


def _settle(waiter: asyncio.Future) -> None:
    """Resolve a queued waiter, unless it went away between the handover and the callback."""
    if not waiter.done():
        waiter.set_result(None)


# Keyed by the resolved limit, not shared blindly: a caller that resolves a different value gets
# its own budget instead of silently resizing one that other coroutines are holding permits from.
_limiters: dict[int, _GlobalLLMLimiter] = {}
_limiters_lock = threading.Lock()


def _shared_limiter(limit: int) -> _GlobalLLMLimiter:
    """Return the process-wide limiter for *limit*."""
    with _limiters_lock:
        limiter = _limiters.get(limit)
        if limiter is None:
            limiter = _GlobalLLMLimiter(limit)
            _limiters[limit] = limiter
        return limiter


def resolve_max_concurrency() -> int:
    """Resolve the LLM fan-out concurrency from ``SKILLSPECTOR_MAX_LLM_CONCURRENCY``.

    Defaults to :data:`DEFAULT_MAX_LLM_CONCURRENCY`. Users on rate-limited
    providers (free tiers with a low RPM) can set it to ``1`` to serialize
    requests across every analyzer instead of bursting up to 10 in parallel — a burst that otherwise
    guarantees 429s, and 429'd batches are dropped from the result (see the
    analyzer fan-out below). Invalid values fall back to the default; values
    below 1 are clamped to 1.
    """
    raw = os.environ.get("SKILLSPECTOR_MAX_LLM_CONCURRENCY", "").strip()
    if not raw:
        return DEFAULT_MAX_LLM_CONCURRENCY
    try:
        value = int(raw)
    except ValueError:
        logger.warning(
            "Invalid SKILLSPECTOR_MAX_LLM_CONCURRENCY=%r (not an int); using %d",
            raw,
            DEFAULT_MAX_LLM_CONCURRENCY,
        )
        return DEFAULT_MAX_LLM_CONCURRENCY
    if value < 1:
        logger.warning("SKILLSPECTOR_MAX_LLM_CONCURRENCY=%d < 1; clamping to 1", value)
        return 1
    return value


# OpenAI suggests ~4 chars per token for English text with BPE tokenizers.
CHARS_PER_TOKEN = 4
CHUNK_OVERLAP_LINES = 50


# ---------------------------------------------------------------------------
# Default structured-output schemas (discovery mode)
# ---------------------------------------------------------------------------


class LLMFinding(BaseModel):
    """A single finding discovered by an LLM analyzer.

    Field names intentionally mirror :class:`~skillspector.models.Finding` so
    that :meth:`to_finding` can produce a graph-state ``Finding`` directly.
    """

    rule_id: str = Field(description="Identifier for the type of finding")
    message: str = Field(description="Short description of the finding")
    severity: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"] = Field(description="Severity level")
    # start_line and confidence carry no ge/le Field bounds on purpose. Pydantic
    # bounds emit JSON-schema minimum/maximum, which some OpenAI-compatible
    # structured-output / tool-calling endpoints reject when they validate the
    # response schema, failing the whole call. The ranges are enforced by the
    # validators below instead, so the guarantee holds without those keywords in
    # the emitted schema. start_line stays required (no default), so a finding
    # with no location is still rejected rather than materialised at line 1;
    # only the numeric bound is removed, not the requiredness.
    start_line: int = Field(description="Starting line number (>= 1)")
    end_line: int | None = Field(default=None, description="Ending line number (optional)")
    confidence: float = Field(default=0.5, description="Confidence score between 0.0 and 1.0")
    explanation: str = Field(default="", description="Why this is a finding (2-3 sentences)")
    remediation: str = Field(default="", description="Actionable steps to fix the issue")

    @field_validator("start_line")
    @classmethod
    def _clamp_start_line(cls, v: int) -> int:
        # Clamp rather than raise: an LLM occasionally returns 0 for a
        # whole-file finding, and normalising to the first line is better than
        # dropping the finding over an off-by-one.
        return v if v >= 1 else 1

    @field_validator("confidence", mode="before")
    @classmethod
    def _normalize_confidence(cls, v: object) -> float:
        # Accept 0-100 scale values from some models, then clamp into [0, 1].
        value = float(cast(Any, v))
        if value > 2.0:
            value = value / 100.0
        return min(1.0, max(0.0, value))

    def to_finding(self, file: str) -> Finding:
        """Convert to a :class:`Finding` for the graph state."""
        # Keep the core LLM module independent from analyzer discovery.  The
        # discovery package imports this module while loading analyzers.
        from skillspector.nodes.analyzers.pattern_defaults import get_category, get_pattern_name

        message = self.message[:4096]
        return Finding(
            rule_id=self.rule_id,
            message=message,
            severity=self.severity,
            confidence=self.confidence,
            file=file,
            start_line=self.start_line,
            end_line=self.end_line,
            category=get_category(self.rule_id),
            pattern=message or get_pattern_name(self.rule_id),
            finding=message,
            explanation=self.explanation,
            remediation=self.remediation,
        )


class LLMAnalysisResult(BaseModel):
    """Structured LLM response containing discovered findings."""

    findings: list[LLMFinding] = Field(default_factory=list)


def estimate_tokens(text: str) -> int:
    """Approximate token count from character length."""
    return len(text) // CHARS_PER_TOKEN


# ---------------------------------------------------------------------------
# Batch dataclass
# ---------------------------------------------------------------------------


@dataclass
class Batch:
    """One unit of work for an LLM call (single file or file-chunk)."""

    file_path: str
    content: str
    start_line: int = 1
    end_line: int | None = None
    findings: list[Finding] = field(default_factory=list)

    @property
    def is_chunk(self) -> bool:
        return self.end_line is not None

    @property
    def file_label(self) -> str:
        label = f"File: {self.file_path}"
        if self.is_chunk:
            label += f" (lines {self.start_line}\u2013{self.end_line})"
        return label


@dataclass(frozen=True)
class BatchFailure:
    """Sanitized failure outcome for one submitted LLM batch."""

    batch: Batch
    error_class: str
    reason: LedgerReason = LedgerReason.LLM_BATCH_FAILED


@dataclass
class BatchExecutionResult:
    """Detailed LLM batch outcome while preserving successful parsed values."""

    successful: list[tuple[Batch, list]] = field(default_factory=list)
    failures: list[BatchFailure] = field(default_factory=list)


def _batch_interval(batch: Batch) -> tuple[int | None, int | None]:
    """Return the canonical ledger range for a submitted batch."""
    if batch.end_line is not None:
        return batch.start_line, batch.end_line
    return None, None


def _uncovered_intervals(
    failed_interval: tuple[int | None, int | None],
    successful_intervals: list[tuple[int | None, int | None]],
) -> list[tuple[int | None, int | None]]:
    """Subtract successful chunk coverage from one failed batch interval."""
    failed_start, failed_end = failed_interval
    if failed_start is None:
        return [] if failed_interval in successful_intervals else [failed_interval]

    assert failed_end is not None
    covered_intervals: list[tuple[int, int]] = []
    for start_line, end_line in successful_intervals:
        if start_line is not None and end_line is not None:
            covered_intervals.append((start_line, end_line))

    uncovered: list[tuple[int | None, int | None]] = []
    next_uncovered_line = failed_start
    for covered_start, covered_end in sorted(covered_intervals):
        if covered_end < next_uncovered_line:
            continue
        if covered_start > failed_end:
            break
        if covered_start > next_uncovered_line:
            uncovered.append((next_uncovered_line, min(failed_end, covered_start - 1)))
        next_uncovered_line = max(next_uncovered_line, covered_end + 1)
        if next_uncovered_line > failed_end:
            break
    if next_uncovered_line <= failed_end:
        uncovered.append((next_uncovered_line, failed_end))
    return uncovered


def ledger_events_for_batches(
    analyzer_id: str,
    outcome: BatchExecutionResult,
) -> tuple[list[InspectionLedgerEvent], AnalyzerStatusEvent]:
    """Project detailed LLM batch execution into terminal ledger evidence."""
    events: list[InspectionLedgerEvent] = []
    successful_ranges: dict[str, list[tuple[int | None, int | None]]] = defaultdict(list)
    for batch, findings in outcome.successful:
        if not isinstance(batch, Batch):
            logger.debug("Skipping ledger projection for malformed successful batch: %r", batch)
            continue
        start_line, end_line = _batch_interval(batch)
        successful_ranges[batch.file_path].append((start_line, end_line))
        events.append(
            ledger_event(
                analyzer_id=analyzer_id,
                outcome=LedgerOutcome.COMPLETED,
                phase="semantic",
                path=batch.file_path,
                start_line=start_line,
                end_line=end_line,
                emitted_finding_ids=[finding.finding_id for finding in findings],
            )
        )

    failed_ranges: dict[str, list[tuple[BatchFailure, tuple[int | None, int | None]]]] = (
        defaultdict(list)
    )
    for failure in outcome.failures:
        if not isinstance(failure.batch, Batch):
            logger.debug("Skipping ledger projection for malformed failed batch: %r", failure.batch)
            continue
        failed_ranges[failure.batch.file_path].append((failure, _batch_interval(failure.batch)))

    for path, failures in failed_ranges.items():
        for failure, failed_range in failures:
            for start_line, end_line in _uncovered_intervals(failed_range, successful_ranges[path]):
                events.append(
                    ledger_event(
                        analyzer_id=analyzer_id,
                        outcome=(
                            LedgerOutcome.PARTIAL
                            if failure.reason is LedgerReason.RUNTIME_LIMIT
                            else outcome_for_llm_batch_failure(failure.reason)
                        ),
                        phase="semantic",
                        path=path,
                        start_line=start_line,
                        end_line=end_line,
                        reason=failure.reason,
                        error_class=failure.error_class,
                    )
                )

    return events, analyzer_status_for_events(analyzer_id, events)


# ---------------------------------------------------------------------------
# Chunking utilities
# ---------------------------------------------------------------------------


def chunk_file_by_lines(
    content: str,
    max_tokens: int,
    overlap_lines: int = CHUNK_OVERLAP_LINES,
) -> list[tuple[str, int, int]]:
    """Split *content* into line-range chunks that each fit within *max_tokens*.

    Returns a list of ``(chunk_text, start_line, end_line)`` tuples where lines
    are 1-indexed.  Consecutive chunks share *overlap_lines* lines of context so
    findings near chunk boundaries still have surrounding code.
    """
    lines = content.splitlines(keepends=True)
    if not lines:
        return [("", 1, 1)]

    chunks: list[tuple[str, int, int]] = []
    start_idx = 0

    while start_idx < len(lines):
        token_count = 0
        end_idx = start_idx

        while end_idx < len(lines):
            line_tokens = estimate_tokens(lines[end_idx])
            if token_count + line_tokens > max_tokens and end_idx > start_idx:
                break
            token_count += line_tokens
            end_idx += 1

        chunk_text = "".join(lines[start_idx:end_idx])
        chunks.append((chunk_text, start_idx + 1, end_idx))  # 1-indexed

        if end_idx >= len(lines):
            break

        next_start = end_idx - overlap_lines
        if next_start <= start_idx:
            next_start = end_idx
        start_idx = next_start

    return chunks


def findings_in_range(
    findings: list[Finding],
    start_line: int,
    end_line: int,
) -> list[Finding]:
    """Return findings whose ``start_line`` falls within [start_line, end_line]."""
    return [f for f in findings if start_line <= f.start_line <= end_line]


def number_lines(content: str, start_line: int = 1) -> str:
    """Prefix each line with its 1-indexed line number (e.g. ``L1:``, ``L2:``).

    For chunks, *start_line* offsets the numbering so the LLM sees real file
    line numbers it can reference in :attr:`LLMFinding.start_line`.
    """
    lines = content.splitlines()
    if not lines:
        return ""
    if os.environ.get("SKILLSPECTOR_COMPACT_PROMPTS", "").strip().lower() in {"1", "true", "yes"}:
        return "\n".join(f"L{start_line + i}: {line}" for i, line in enumerate(lines))
    end = start_line + len(lines) - 1
    width = len(str(end))
    return "\n".join(f"L{start_line + i:0>{width}}: {line}" for i, line in enumerate(lines))


def _message_text(response: object) -> str:
    """Extract provider-normalized text from a LangChain chat response."""
    if not isinstance(response, BaseMessage):
        raise TypeError(f"Expected BaseMessage from chat model, got {type(response).__name__}")
    return str(response.text)


def _raw_response_text(response: object) -> str:
    """Extract raw analyzer text from LangChain and CLI adapter messages."""
    if isinstance(response, _AgentCLIMessage):
        return str(response.content)
    return _message_text(response)


BASE_ANALYSIS_PROMPT = """\
{analyzer_prompt}

Analyze the following skill file for security issues matching the criteria above.
Reference line numbers (shown as L-prefixes) when reporting findings.

## {file_label}
```
{numbered_content}
```

## Output guidelines

- Most files are clean — an empty findings list is expected and correct when
  no genuine issues exist.  Do not manufacture findings to fill the response.
- Precision over recall: only report issues you are confident about.  It is
  far better to miss an edge case than to report a false positive.
- Be precise: report only genuine issues, not speculative ones."""


# ---------------------------------------------------------------------------
# Base LLM Analyzer
# ---------------------------------------------------------------------------


class LLMAnalyzerBase:
    """Per-file / per-chunk LLM analyzer.

    Subclass, supply an ``analyzer_prompt`` string, and optionally override
    :meth:`build_prompt` / :meth:`parse_response`.  The defaults produce a
    prompt with line-numbered file content and parse :class:`LLMAnalysisResult`
    (a list of :class:`LLMFinding`).

    Override :attr:`response_schema` with a different Pydantic model for
    custom structured output, or set it to ``None`` for raw-string mode.

    **Precision-over-recall default**: ``BASE_ANALYSIS_PROMPT`` appends
    output guidelines that instruct the LLM to prefer empty findings over
    false positives.  This applies to all analyzers that use the default
    :meth:`build_prompt`.  Subclasses that override :meth:`build_prompt`
    (e.g. the meta-analyzer) control their own output instructions.
    """

    response_schema: type | None = LLMAnalysisResult

    def __init__(
        self,
        base_prompt: str,
        model: str,
        *,
        node: str = "llm_analyzer",
        timeout: float | None | Callable[[], float | None] = None,
    ):
        self.base_prompt = base_prompt
        self.model = model
        self._timeout = timeout
        self._dynamic_timeout = callable(timeout)
        self._input_budget = get_max_input_tokens(model)
        try:
            self._llm = get_chat_model(model=model, timeout=self._require_time_remaining())
        except ValueError:
            raise
        except Exception:
            self._require_time_remaining()
            raise
        self._require_time_remaining()
        # Native SDK retries cannot re-read a workflow-wide deadline between
        # attempts.  A dynamic deadline therefore uses our explicit retry loop,
        # which checks and caps every retry/backoff against remaining time.
        native_retries = 0 if self._dynamic_timeout else API_CONNECTION_MAX_RETRIES
        self._uses_native_connection_retries = _uses_native_connection_retries(
            self._llm,
            max_retries=native_retries,
        )
        self._structured_llm = (
            bind_structured_output(self._llm, self.response_schema, model)
            if self.response_schema
            else None
        )
        self._usage_collector = new_inference_usage_collector(
            node=node,
            request_kind="structured_output" if self.response_schema else "chat_completion",
            model=model,
            chat_model=self._llm,
        )

    def _remaining_timeout(self) -> float | None:
        if callable(self._timeout):
            remaining = self._timeout()
        else:
            remaining = self._timeout
        if remaining is None:
            return None
        return max(0.0, float(remaining))

    def _require_time_remaining(self) -> float | None:
        """Return the current provider timeout or fail before starting work."""
        remaining = self._remaining_timeout()
        if remaining is not None and remaining <= 0:
            raise LLMRuntimeLimitError("shared scan runtime limit reached")
        return remaining

    def _sleep_before_retry(self, delay: float) -> None:
        """Sleep no longer than the current shared deadline permits."""
        remaining = self._require_time_remaining()
        time.sleep(delay if remaining is None else min(delay, remaining))

    async def _asleep_before_retry(self, delay: float) -> None:
        """Asynchronously sleep no longer than the shared deadline permits."""
        remaining = self._require_time_remaining()
        await asyncio.sleep(delay if remaining is None else min(delay, remaining))

    def _model_for_call(self) -> tuple[object, object | None]:
        remaining = self._require_time_remaining()
        if not self._dynamic_timeout:
            return self._llm, self._structured_llm
        provider = get_active_provider()
        token_changed = False
        if isinstance(provider, GeminiProvider) and isinstance(self._llm, BaseChatOpenAI):
            credentials = provider.resolve_credentials(timeout=remaining)
            if credentials is None:
                raise ValueError("Gemini credentials unavailable.")
            token = self._llm.openai_api_key
            token_changed = token is None or token.get_secret_value() != credentials[0]
            remaining = self._require_time_remaining()
        if not token_changed and _retarget_request_timeout(self._llm, remaining):
            # Native retries were already disabled for the dynamic-deadline case in
            # ``__init__``, and the structured runnable wraps this same model instance.
            return self._llm, self._structured_llm
        try:
            llm = get_chat_model(model=self.model, timeout=remaining)
        except ValueError:
            raise
        except Exception:
            self._require_time_remaining()
            raise
        self._require_time_remaining()
        _uses_native_connection_retries(llm, max_retries=0)
        effective_provider = chat_model_provider_name(llm)
        if effective_provider is not None:
            self._usage_collector.set_provider(effective_provider)
        self._usage_collector.set_controls(
            chat_model_requested_controls(llm),
            chat_model_controls(llm),
        )
        structured = (
            bind_structured_output(llm, self.response_schema, self.model)
            if self.response_schema
            else None
        )
        if token_changed:
            self._llm, self._structured_llm = llm, structured
        return llm, structured

    @property
    def inference_usage(self) -> list[InferenceUsageRecord]:
        """Provider-reported usage captured for this analyzer instance."""
        return list(self._usage_collector.snapshot())

    @property
    def response_received(self) -> bool:
        """Whether any analyzer call received a provider response."""
        return self._usage_collector.response_received

    # -- Batching -----------------------------------------------------------

    def _estimate_extra_overhead(self, findings: list[Finding]) -> int:
        """Token overhead beyond the base prompt (e.g. formatted findings).

        Override in subclasses that add findings text to the prompt.
        """
        return 0

    def get_batches(
        self,
        file_paths: list[str],
        file_cache: dict[str, str],
        findings: list[Finding] | None = None,
    ) -> list[Batch]:
        """Create one :class:`Batch` per file, splitting oversized files into chunks."""
        base_overhead = estimate_tokens(self.base_prompt)

        findings_by_file: dict[str, list[Finding]] = defaultdict(list)
        if findings:
            for f in findings:
                findings_by_file[f.file].append(f)

        batches: list[Batch] = []
        for path in file_paths:
            content = file_cache.get(path) or "No content available for this file."
            file_findings = findings_by_file.get(path, [])

            extra = self._estimate_extra_overhead(file_findings)
            content_budget = max(self._input_budget - base_overhead - extra, 1024)

            content_tokens = estimate_tokens(content)
            if content_tokens <= content_budget:
                batches.append(
                    Batch(
                        file_path=path,
                        content=content,
                        findings=file_findings,
                    )
                )
            else:
                chunk_budget = max(int(content_budget), 1024)
                for chunk_text, s_line, e_line in chunk_file_by_lines(content, chunk_budget):
                    chunk_findings = findings_in_range(file_findings, s_line, e_line)
                    batches.append(
                        Batch(
                            file_path=path,
                            content=chunk_text,
                            start_line=s_line,
                            end_line=e_line,
                            findings=chunk_findings,
                        )
                    )

        return batches

    # -- Prompt / parse -----------------------------------------------------

    def build_prompt(self, batch: Batch, **kwargs: object) -> str:
        """Build the LLM prompt for a single batch.

        The default wraps :attr:`base_prompt` with line-numbered file content
        so the LLM can reference exact line numbers in its findings.
        Override in subclasses that need a custom prompt layout.
        """
        numbered = number_lines(batch.content, batch.start_line)
        return append_output_language_instruction(
            BASE_ANALYSIS_PROMPT.format(
                analyzer_prompt=self.base_prompt,
                file_label=batch.file_label,
                numbered_content=numbered,
            )
        )

    def parse_response(self, response: object, batch: Batch) -> list[Finding]:
        """Parse the LLM response for a single batch.

        The default converts each :class:`LLMFinding` to a :class:`Finding`
        via :meth:`LLMFinding.to_finding`.  Override in subclasses that use a
        different ``response_schema`` or raw-string mode.
        """
        if isinstance(response, LLMAnalysisResult):
            return [f.to_finding(batch.file_path) for f in response.findings]
        raise NotImplementedError(
            "Override parse_response for custom response_schema or raw-string mode"
        )

    # -- Run loop -----------------------------------------------------------

    def _invoke_batch(self, batch: Batch, prompt: str) -> tuple[Batch, list]:
        """Invoke and parse one batch synchronously."""
        logger.debug(
            "LLM call for %s (tokens~%d, findings=%d)",
            batch.file_label,
            estimate_tokens(prompt),
            len(batch.findings),
        )
        llm, structured_llm = self._model_for_call()
        if structured_llm:
            try:
                response = _invoke_with_usage(structured_llm, prompt, self._usage_collector)
            except (StructuredOutputParseError, ValidationError) as exc:
                raise _StructuredResponseValidationError from exc
        else:
            response = _raw_response_text(_invoke_with_usage(llm, prompt, self._usage_collector))
        logger.debug("LLM response for %s", batch.file_label)
        return batch, self.parse_response(response, batch)

    def _invoke_batch_with_retries(
        self,
        batch: Batch,
        prompt: str,
        *,
        retry_outcome: _ProviderRetryOutcome | None = None,
    ) -> tuple[Batch, list]:
        """Run one batch with bounded retries for malformed output and transient failures."""
        retry_outcome = retry_outcome or _ProviderRetryOutcome()
        structured_retries = 0
        connection_retries = 0
        for attempt in range(1, LLM_BATCH_MAX_ATTEMPTS + 1):
            try:
                return self._invoke_batch(batch, prompt)
            except _StructuredResponseValidationError:
                if (
                    structured_retries >= STRUCTURED_RESPONSE_MAX_ATTEMPTS - 1
                    or attempt == LLM_BATCH_MAX_ATTEMPTS
                ):
                    self._require_time_remaining()
                    raise
                delay = STRUCTURED_RESPONSE_RETRY_DELAYS_SECONDS[structured_retries]
                structured_retries += 1
                logger.warning(
                    "LLM structured response validation failed for %s; retrying in %.2fs (%d/%d)",
                    batch.file_label,
                    delay,
                    structured_retries,
                    STRUCTURED_RESPONSE_MAX_RETRIES,
                )
                self._sleep_before_retry(delay)
            except LLMRuntimeLimitError:
                raise
            except Exception as exc:
                retryable = _is_retryable_provider_error(exc)
                if not retryable:
                    self._require_time_remaining()
                    raise
                if self._uses_native_connection_retries and _native_retries_cover_provider_error(
                    exc
                ):
                    # Ownership does not establish how many native requests ran.
                    # Keep an unobserved SDK retry outcome generic.
                    raise
                if connection_retries >= len(API_CONNECTION_RETRY_DELAYS_SECONDS):
                    retry_outcome.reason = LedgerReason.LLM_CONNECTION_RETRIES_EXHAUSTED
                    raise
                if attempt == LLM_BATCH_MAX_ATTEMPTS:
                    # Structured-output attempts may have used the shared cap
                    # before the provider retry budget was exhausted.
                    raise
                delay = _provider_retry_delay(exc, connection_retries)
                remaining = self._remaining_timeout()
                if remaining is not None and remaining <= delay:
                    # Preserve the provider exception while recording the actual
                    # stop condition, even if no provider retry could begin.
                    retry_outcome.reason = LedgerReason.RUNTIME_LIMIT
                    raise
                connection_retries += 1
                logger.warning(
                    "Transient LLM provider failure for %s; retrying in %.2fs (%d/%d)",
                    batch.file_label,
                    delay,
                    connection_retries,
                    API_CONNECTION_MAX_RETRIES,
                )
                self._sleep_before_retry(delay)

        raise AssertionError("bounded retry loop must return or raise")

    async def _ainvoke_batch(self, batch: Batch, prompt: str) -> tuple[Batch, list]:
        """Invoke and parse one batch asynchronously."""
        logger.debug(
            "LLM call for %s (tokens~%d, findings=%d)",
            batch.file_label,
            estimate_tokens(prompt),
            len(batch.findings),
        )
        llm, structured_llm = self._model_for_call()
        if structured_llm:
            try:
                response = await _ainvoke_with_usage(structured_llm, prompt, self._usage_collector)
            except (StructuredOutputParseError, ValidationError) as exc:
                raise _StructuredResponseValidationError from exc
        else:
            response = _raw_response_text(
                await _ainvoke_with_usage(llm, prompt, self._usage_collector)
            )
        logger.debug("LLM response for %s", batch.file_label)
        return batch, self.parse_response(response, batch)

    async def _ainvoke_batch_with_retries(
        self,
        batch: Batch,
        prompt: str,
        *,
        retry_outcome: _ProviderRetryOutcome | None = None,
    ) -> tuple[Batch, list]:
        """Asynchronously run one batch with bounded malformed-output and provider retries."""
        retry_outcome = retry_outcome or _ProviderRetryOutcome()
        structured_retries = 0
        connection_retries = 0
        for attempt in range(1, LLM_BATCH_MAX_ATTEMPTS + 1):
            try:
                return await self._ainvoke_batch(batch, prompt)
            except _StructuredResponseValidationError:
                if (
                    structured_retries >= STRUCTURED_RESPONSE_MAX_ATTEMPTS - 1
                    or attempt == LLM_BATCH_MAX_ATTEMPTS
                ):
                    self._require_time_remaining()
                    raise
                delay = STRUCTURED_RESPONSE_RETRY_DELAYS_SECONDS[structured_retries]
                structured_retries += 1
                logger.warning(
                    "LLM structured response validation failed for %s; retrying in %.2fs (%d/%d)",
                    batch.file_label,
                    delay,
                    structured_retries,
                    STRUCTURED_RESPONSE_MAX_RETRIES,
                )
                await self._asleep_before_retry(delay)
            except LLMRuntimeLimitError:
                raise
            except Exception as exc:
                retryable = _is_retryable_provider_error(exc)
                if not retryable:
                    self._require_time_remaining()
                    raise
                if self._uses_native_connection_retries and _native_retries_cover_provider_error(
                    exc
                ):
                    # Ownership does not establish how many native requests ran.
                    # Keep an unobserved SDK retry outcome generic.
                    raise
                if connection_retries >= len(API_CONNECTION_RETRY_DELAYS_SECONDS):
                    retry_outcome.reason = LedgerReason.LLM_CONNECTION_RETRIES_EXHAUSTED
                    raise
                if attempt == LLM_BATCH_MAX_ATTEMPTS:
                    # Structured-output attempts may have used the shared cap
                    # before the provider retry budget was exhausted.
                    raise
                delay = _provider_retry_delay(exc, connection_retries)
                remaining = self._remaining_timeout()
                if remaining is not None and remaining <= delay:
                    # Preserve the provider exception while recording the actual
                    # stop condition, even if no provider retry could begin.
                    retry_outcome.reason = LedgerReason.RUNTIME_LIMIT
                    raise
                connection_retries += 1
                logger.warning(
                    "Transient LLM provider failure for %s; retrying in %.2fs (%d/%d)",
                    batch.file_label,
                    delay,
                    connection_retries,
                    API_CONNECTION_MAX_RETRIES,
                )
                await self._asleep_before_retry(delay)

        raise AssertionError("bounded retry loop must return or raise")

    def run_batches(
        self,
        batches: list[Batch],
        **kwargs: object,
    ) -> list[tuple[Batch, list]]:
        """Execute LLM calls for all *batches*, returning per-batch parsed results.

        The element type of the inner list depends on the subclass: the default
        :meth:`parse_response` returns :class:`Finding` objects; subclasses may
        return dicts or other types.
        """
        outcome = self.run_batches_detailed(batches, **kwargs)
        self._last_batch_outcome = outcome
        return outcome.successful

    def run_batches_detailed(
        self,
        batches: list[Batch],
        **kwargs: object,
    ) -> BatchExecutionResult:
        """Execute batches and retain each sanitized failure alongside successes."""
        outcome = BatchExecutionResult()
        for batch in batches:
            retry_outcome = _ProviderRetryOutcome()
            try:
                prompt = self.build_prompt(batch, **kwargs)
                result = self._invoke_batch_with_retries(batch, prompt, retry_outcome=retry_outcome)
                outcome.successful.append(result)
            except _StructuredResponseValidationError:
                logger.warning(
                    "LLM structured response validation failed for %s after %d attempts",
                    batch.file_label,
                    STRUCTURED_RESPONSE_MAX_ATTEMPTS,
                )
                outcome.failures.append(
                    BatchFailure(
                        batch=batch,
                        error_class=ValidationError.__name__,
                        reason=LedgerReason.LLM_STRUCTURED_RESPONSE_INVALID,
                    )
                )
            except LLMRuntimeLimitError as exc:
                outcome.failures.append(
                    BatchFailure(
                        batch=batch,
                        error_class=type(exc).__name__,
                        reason=LedgerReason.RUNTIME_LIMIT,
                    )
                )
            except (ValueError, NotImplementedError):
                raise
            except Exception as exc:
                logger.warning("LLM batch failed for %s (%s)", batch.file_label, type(exc).__name__)
                outcome.failures.append(
                    BatchFailure(
                        batch=batch,
                        error_class=_provider_failure_class(exc),
                        reason=retry_outcome.reason,
                    )
                )
        return outcome

    async def arun_batches(
        self,
        batches: list[Batch],
        *,
        max_concurrency: int | None = None,
        **kwargs: object,
    ) -> list[tuple[Batch, list]]:
        """Execute LLM calls for all *batches* concurrently.

        Uses ``asyncio.gather`` with a semaphore to run up to
        *max_concurrency* LLM requests in parallel.  Both cross-file and
        cross-chunk batches are parallelized in a single gather call.

        When *max_concurrency* is ``None`` (the default) it is resolved from
        ``SKILLSPECTOR_MAX_LLM_CONCURRENCY`` via :func:`resolve_max_concurrency`,
        so users on rate-limited providers can serialize the fan-out; an
        explicit argument still wins.

        Failures are isolated per batch: transient provider failures (including
        connection and timeout errors, 408/409/425/429 and 5xx responses, and
        Bedrock throttling/service errors) receive three bounded retries when
        the chat model has no native retry support. Backoff is 500ms, 1s, and
        2s for transport and service failures, or 5s, 15s, and 30s for rate
        limits, unless a bounded provider ``Retry-After`` hint asks for longer.
        OpenAI and Anthropic chat models use their native three-retry policy
        instead when the timeout is static. Bedrock SDK retries are disabled so
        the same coordinator budget handles its failures without a second
        retry layer. A dynamic workflow deadline disables configurable native
        retries so each coordinator retry can re-check and cap its delay
        against remaining time.
        Unrecovered errors cost only their own batch and are omitted from the result.
        Malformed structured responses (Pydantic ``ValidationError`` or CLI
        JSON parse failures) receive three bounded exponential-backoff retries
        and are then isolated to their batch. A batch makes at most seven outer
        chat-model invocations even when both
        retry policies apply; native provider retries can make additional HTTP
        requests within one invocation.
        Callers can detect partial results by comparing the returned batches
        against the submitted ones.  Other ``ValueError`` instances and
        ``NotImplementedError`` signal misconfiguration rather than infra trouble
        and keep propagating.

        The return type mirrors :meth:`run_batches`.
        """
        outcome = await self.arun_batches_detailed(
            batches, max_concurrency=max_concurrency, **kwargs
        )
        self._last_batch_outcome = outcome
        return outcome.successful

    async def arun_batches_detailed(
        self,
        batches: list[Batch],
        *,
        max_concurrency: int | None = None,
        **kwargs: object,
    ) -> BatchExecutionResult:
        """Execute batches concurrently and retain sanitized per-batch failures."""
        # Resolved from the environment: one budget for the whole process, because that is what
        # the variable promises — "requests in parallel", not "requests in parallel per analyzer".
        # An explicit argument keeps its documented meaning and stays local to this call: a caller
        # that passes a number is asking for a fan-out width, not for a share of the budget.
        sem: _GlobalLLMLimiter | asyncio.Semaphore
        if max_concurrency is None:
            sem = _shared_limiter(resolve_max_concurrency())
        else:
            sem = asyncio.Semaphore(max_concurrency)

        async def _process(
            batch: Batch, retry_outcome: _ProviderRetryOutcome
        ) -> tuple[Batch, list]:
            async with sem:
                prompt = self.build_prompt(batch, **kwargs)
                return await self._ainvoke_batch_with_retries(
                    batch, prompt, retry_outcome=retry_outcome
                )

        retry_outcomes = [_ProviderRetryOutcome() for _ in batches]
        results = await asyncio.gather(
            *[_process(b, retry) for b, retry in zip(batches, retry_outcomes, strict=True)],
            return_exceptions=True,
        )
        outcome = BatchExecutionResult()
        for batch, result, retry_outcome in zip(batches, results, retry_outcomes, strict=True):
            if isinstance(result, _StructuredResponseValidationError):
                logger.warning(
                    "LLM structured response validation failed for %s after %d attempts",
                    batch.file_label,
                    STRUCTURED_RESPONSE_MAX_ATTEMPTS,
                )
                outcome.failures.append(
                    BatchFailure(
                        batch=batch,
                        error_class=ValidationError.__name__,
                        reason=LedgerReason.LLM_STRUCTURED_RESPONSE_INVALID,
                    )
                )
                continue
            if isinstance(result, LLMRuntimeLimitError):
                outcome.failures.append(
                    BatchFailure(
                        batch=batch,
                        error_class=type(result).__name__,
                        reason=LedgerReason.RUNTIME_LIMIT,
                    )
                )
                continue
            if isinstance(result, (ValueError, NotImplementedError)):
                raise result
            if isinstance(result, BaseException):
                logger.warning(
                    "LLM batch failed for %s (%s)", batch.file_label, type(result).__name__
                )
                outcome.failures.append(
                    BatchFailure(
                        batch=batch,
                        error_class=_provider_failure_class(result),
                        reason=retry_outcome.reason,
                    )
                )
                continue
            outcome.successful.append(result)
        return outcome

    # -- Convenience --------------------------------------------------------

    def collect_findings(
        self,
        batch_results: list[tuple[Batch, list]],
    ) -> list[Finding]:
        """Flatten per-batch results into a single :class:`Finding` list.

        Intended for discovery-mode analyzers where :meth:`parse_response`
        returns :class:`Finding` objects.  A typical node can do::

            batches = analyzer.get_batches(files, file_cache)
            results = analyzer.run_batches(batches)
            return {"findings": analyzer.collect_findings(results)}
        """
        return [f for _, items in batch_results for f in items]
