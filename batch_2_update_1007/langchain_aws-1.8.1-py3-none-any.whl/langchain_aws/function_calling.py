"""Methods for creating function specs in the style of Bedrock Functions
for supported model providers"""

import json
from typing import (
    Annotated,
    Any,
    Callable,
    Dict,
    List,
    Literal,
    Optional,
    Union,
    cast,
)

from langchain_core.messages import ToolCall
from langchain_core.output_parsers import (
    BaseGenerationOutputParser,
    JsonOutputKeyToolsParser,
    PydanticToolsParser,
)
from langchain_core.outputs import ChatGeneration, Generation
from langchain_core.prompts.chat import AIMessage
from langchain_core.tools import BaseTool
from langchain_core.utils.function_calling import convert_to_openai_tool
from langchain_core.utils.pydantic import PydanticBaseModel, TypeBaseModel
from pydantic import BaseModel, ConfigDict, SkipValidation
from typing_extensions import TypedDict

PYTHON_TO_JSON_TYPES = {
    "str": "string",
    "int": "integer",
    "float": "number",
    "bool": "boolean",
}

SYSTEM_PROMPT_FORMAT = """In this environment you have access to a set of tools you can use to answer the user's question.

You may call them like this:
<function_calls>
<invoke>
<tool_name>$TOOL_NAME</tool_name>
<parameters>
<$PARAMETER_NAME>$PARAMETER_VALUE</$PARAMETER_NAME>
...
</parameters>
</invoke>
</function_calls>

Here are the tools available:
<tools>
{formatted_tools}
</tools>"""  # noqa: E501

TOOL_FORMAT = """<tool_description>
<tool_name>{tool_name}</tool_name>
<description>{tool_description}</description>
<parameters>
{formatted_parameters}
</parameters>
</tool_description>"""

TOOL_PARAMETER_FORMAT = """<parameter>
<name>{parameter_name}</name>
<type>{parameter_type}</type>
<description>{parameter_description}</description>
</parameter>"""


class AnthropicTool(TypedDict):
    name: str
    description: str
    input_schema: Dict[str, Any]


def _tools_in_params(params: dict) -> bool:
    return "tools" in params or (
        "extra_body" in params and params["extra_body"].get("tools")
    )


class _AnthropicToolUse(TypedDict):
    type: Literal["tool_use"]
    name: str
    input: dict
    id: str


def _lc_tool_calls_to_anthropic_tool_use_blocks(
    tool_calls: List[ToolCall],
) -> List[_AnthropicToolUse]:
    blocks = []
    for tool_call in tool_calls:
        blocks.append(
            _AnthropicToolUse(
                type="tool_use",
                name=tool_call["name"],
                input=tool_call["args"],
                id=cast(str, tool_call["id"]),
            )
        )
    return blocks


def _get_type(parameter: Dict[str, Any]) -> str:
    if "type" in parameter:
        return parameter["type"]
    if "anyOf" in parameter:
        return json.dumps({"anyOf": parameter["anyOf"]}, ensure_ascii=False)
    if "allOf" in parameter:
        return json.dumps({"allOf": parameter["allOf"]}, ensure_ascii=False)
    return json.dumps(parameter, ensure_ascii=False)


def get_system_message(tools: List[AnthropicTool]) -> str:
    tools_data: List[Dict] = [
        {
            "tool_name": tool["name"],
            "tool_description": tool["description"],
            "formatted_parameters": "\n".join(
                [
                    TOOL_PARAMETER_FORMAT.format(
                        parameter_name=name,
                        parameter_type=_get_type(parameter),
                        parameter_description=parameter.get("description"),
                    )
                    for name, parameter in tool["input_schema"]["properties"].items()
                ]
            ),
        }
        for tool in tools
    ]
    tools_formatted = "\n".join(
        [
            TOOL_FORMAT.format(
                tool_name=tool["tool_name"],
                tool_description=tool["tool_description"],
                formatted_parameters=tool["formatted_parameters"],
            )
            for tool in tools_data
        ]
    )
    return SYSTEM_PROMPT_FORMAT.format(formatted_tools=tools_formatted)


class FunctionDescription(TypedDict):
    """Representation of a callable function to send to an LLM."""

    name: str
    """The name of the function."""
    description: str
    """A description of the function."""
    parameters: dict
    """The parameters of the function."""


class ToolDescription(TypedDict):
    """Representation of a callable function to the OpenAI API."""

    type: Literal["function"]
    function: FunctionDescription


def _repair_stringified_json_args(
    args: Dict[str, Any], properties: Dict[str, Any]
) -> Dict[str, Any]:
    """Unwrap tool-call arguments if the model converted them to JSON strings."""
    repaired: Dict[str, Any] = {}
    for key, value in args.items():
        declared = (properties.get(key) or {}).get("type")
        if not isinstance(value, str) or declared not in ("array", "object"):
            repaired[key] = value
            continue
        try:
            loaded = json.loads(value)
        except json.JSONDecodeError:
            repaired[key] = value
            continue
        expected_type: type = list if declared == "array" else dict
        if isinstance(loaded, expected_type):
            repaired[key] = loaded
        elif (
            isinstance(loaded, dict)
            and key in loaded
            and isinstance(loaded[key], expected_type)
        ):
            repaired[key] = loaded[key]
        else:
            repaired[key] = value
    return repaired


def _repair_stringified_tool_call_message(
    message: AIMessage, properties: Dict[str, Any]
) -> AIMessage:
    """Return ``message`` with str tool-call args repaired."""
    if not message.tool_calls:
        return message
    repaired_calls = [
        {**tc, "args": _repair_stringified_json_args(tc["args"], properties)}
        for tc in message.tool_calls
    ]
    if repaired_calls == message.tool_calls:
        return message
    return message.model_copy(update={"tool_calls": repaired_calls})


def _repair_generations(
    result: List[Generation], properties: Optional[Dict[str, Any]]
) -> List[Generation]:
    if not properties:
        return result
    repaired: List[Generation] = []
    for gen in result:
        if (
            isinstance(gen, ChatGeneration)
            and isinstance(gen.message, AIMessage)
            and gen.message.tool_calls
        ):
            new_message = _repair_stringified_tool_call_message(gen.message, properties)
            if new_message is not gen.message:
                gen = gen.__class__(
                    message=new_message, generation_info=gen.generation_info
                )
        repaired.append(gen)
    return repaired


class _RepairingParserMixin(BaseModel):
    schema_properties: Optional[Dict[str, Any]] = None

    def parse_result(self, result: List[Generation], *, partial: bool = False) -> Any:
        result = _repair_generations(result, self.schema_properties)
        return super().parse_result(result, partial=partial)  # type: ignore[misc]


class _RepairingPydanticToolsParser(_RepairingParserMixin, PydanticToolsParser):
    """``PydanticToolsParser`` that repairs model-stringified tool args."""


class _RepairingJsonOutputKeyToolsParser(
    _RepairingParserMixin, JsonOutputKeyToolsParser
):
    """``JsonOutputKeyToolsParser`` that repairs model-stringified tool args."""


class ToolsOutputParser(BaseGenerationOutputParser):
    first_tool_only: bool = False
    args_only: bool = False
    pydantic_schemas: Optional[List[Annotated[TypeBaseModel, SkipValidation()]]] = None
    schema_properties: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(
        extra="forbid",
    )

    def parse_result(self, result: List[Generation], *, partial: bool = False) -> Any:
        """Parse a list of candidate model Generations into a specific format.

        Args:
            result: A list of Generations to be parsed. The Generations are assumed
                to be different candidate outputs for a single model input.

        Returns:
            Structured output.

        """
        result = _repair_generations(result, self.schema_properties)
        if (
            not result
            or not isinstance(result[0], ChatGeneration)
            or not isinstance(result[0].message, AIMessage)
            or not result[0].message.tool_calls
        ):
            return None if self.first_tool_only else []
        tool_calls: Any = result[0].message.tool_calls
        if self.pydantic_schemas:
            tool_calls = [self._pydantic_parse(tc) for tc in tool_calls]
        elif self.args_only:
            tool_calls = [tc["args"] for tc in tool_calls]
        else:
            pass

        if self.first_tool_only:
            return tool_calls[0]
        else:
            return tool_calls

    def _pydantic_parse(self, tool_call: ToolCall) -> PydanticBaseModel:
        cls_ = {schema.__name__: schema for schema in self.pydantic_schemas or []}[
            tool_call["name"]
        ]
        return cls_(**tool_call["args"])


def convert_to_anthropic_tool(
    tool: Union[Dict[str, Any], TypeBaseModel, Callable, BaseTool],
) -> Union[AnthropicTool, Dict]:
    # already in Anthropic tool format
    if isinstance(tool, dict) and all(
        k in tool for k in ("name", "description", "input_schema")
    ):
        tool["description"] = tool["description"] or tool["name"]
        return AnthropicTool(tool)  # type: ignore
    else:
        formatted = convert_to_openai_tool(tool)["function"]
        formatted["description"] = formatted.get("description") or formatted["name"]
        return AnthropicTool(
            name=formatted["name"],
            description=formatted["description"],
            input_schema=formatted["parameters"],
        )
